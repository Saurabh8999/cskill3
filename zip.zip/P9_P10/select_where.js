var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "123456",
  database: "mynodedb"
});

con.connect(function(err) {
  if (err) throw err;
  con.query("SELECT * FROM ssb.customers WHERE address = 'Park Lane 38'", function (err, result) {
    if (err) throw err;
    console.log(result);
  });
});