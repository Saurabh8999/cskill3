var events = require('events');
var eventEmitter = new events.EventEmitter();

//Create an event handler:
var myEventHandler = function () {
  console.log('There is relaxation in covid guidelines, Hence students can come to college offline');
}

//Assign the event handler to an event:
eventEmitter.on('relaxation in covid guidelines', myEventHandler);

//Fire the 'scream' event:
eventEmitter.emit('relaxation in covid guidelines');
